package org.aka.client;

import java.io.*;
import java.net.*;
import java.nio.charset.*;
import java.util.*;
import java.util.stream.*;
import org.json.simple.*;

/**
 *  The client.
 */
public final class Client
{
    //////////
    //  Constants
    /** The host name where the server resides. */
    public static final String SERVER_URL = "localhost"; //$NON-NLS-1$
    /** The port at which the server listens */
    public static final int SERVER_PORT= 8080;
    /** The context where the server resides. */
    public static final String SERVER_CONTEXT = "server/server"; //$NON-NLS-1$

    //////////
    //  Operations
    /**
     *  The client entry point.
     *
     *  @param args
     *      The command-line arguments - each one a CSV file name to read.
     */
    public static void main(String[] args)
    {
        if (args.length == 0)
        {
            System.out.println("No files to process"); //$NON-NLS-1$
            System.exit(0);
        }
        //  Read all files, line by line
        for (String arg : args)
        {
            System.out.println("*** Reading file " + arg); //$NON-NLS-1$
            try (FileInputStream fis = new FileInputStream(arg);
                 InputStreamReader isr = new InputStreamReader(fis);
                 BufferedReader br = new BufferedReader(isr))
            {
                int lineNumber = 0;
                String line;
                while ((line = br.readLine()) != null)
                {   //  Ignore whole-line comments and empty lines
                    lineNumber++;
                    line = line.trim();
                    if (line.length() == 0 || line.startsWith("#")) //$NON-NLS-1$
                    {
                        continue;
                    }
                    //  Try parsing the line
                    List<String> chunks = Stream.of(line.split(",")).collect(Collectors.toList()); //$NON-NLS-1$
                    //  IMPORTANT - if the last chunk is empty
                    //  (e.g. line ends with ",", meaning no postcode,
                    //  correct for that
                    if (line.endsWith(",")) //$NON-NLS-1$
                    {   //  Add an artificial chunk
                        chunks.add(""); //$NON-NLS-1$
                    }
                    if (chunks.size() != 8 || chunks.get(0).length() == 0)
                    {   //  OOPS! Report and ignore
                        System.out.println("ERROR in line " + lineNumber + " (" + line + ")"); //$NON-NLS-1$ //$NON-NLS-2$ //$NON-NLS-3$
                    }
                    else
                    {
                        _processChunks(chunks);
                    }
                }
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }

            //  Now we test the customer info saved on the server
            _testCustomerInfos();
        }
    }

    //////////
    //  Implementation
    private static final Map<String, String> _jsons = new HashMap<>();   //  ref -> json

    //  Helpers
    private static void _processChunks(List<String> chunks)
    {
        //  Create a JSON object - some fields are mandatory...
        JSONObject obj = new JSONObject();
        obj.put("CustomerRef", chunks.get(0)); //$NON-NLS-1$
        //  ...and others are optional
        _addOptionalField(obj, "CustomerName", chunks.get(1)); //$NON-NLS-1$
        _addOptionalField(obj, "AddressLine1", chunks.get(2)); //$NON-NLS-1$
        _addOptionalField(obj, "AddressLine2", chunks.get(3)); //$NON-NLS-1$
        _addOptionalField(obj, "Town", chunks.get(4)); //$NON-NLS-1$
        _addOptionalField(obj, "County", chunks.get(5)); //$NON-NLS-1$
        _addOptionalField(obj, "Country", chunks.get(6)); //$NON-NLS-1$
        _addOptionalField(obj, "Postcode", chunks.get(7)); //$NON-NLS-1$

        //  Serialise to a string
        String json = obj.toJSONString();

        //  And save for future testing
        _jsons.put(chunks.get(0), json);

        //  Now we need to send JSON string as payload to the server using the POST method
        try
        {
            URL url = new URL("http://" + SERVER_URL + //$NON-NLS-1$
                              ":" + SERVER_PORT + //$NON-NLS-1$
                              "/" + SERVER_CONTEXT); //$NON-NLS-1$
            HttpURLConnection connection = (HttpURLConnection)url.openConnection();
            connection.setRequestMethod("POST"); //$NON-NLS-1$
            connection.setDoOutput(true);
            OutputStream os = connection.getOutputStream();
            os.write(json.getBytes(StandardCharsets.UTF_8));
            os.flush();
            os.close();
            int responseCode = connection.getResponseCode();
            if (responseCode != HttpURLConnection.HTTP_OK)
            {   //  OOPS! Error - JSON not POSTed, so no
                //  point in trying to GET it back
                _jsons.remove(chunks.get(0));
                System.out.println("POST request did not work: " + responseCode); //$NON-NLS-1$
            }
        }
        catch (IOException ex)
        {
            ex.printStackTrace();
        }
    }

    private static void _addOptionalField(JSONObject obj, String fieldName, String fieldValue)
    {
        if (fieldValue.length() != 0)
        {
            obj.put(fieldName, fieldValue);
        }
    }

    private static void _testCustomerInfos()
    {
        for (String customerRef : _jsons.keySet())
        {
            try
            {
                //  Prepare the GET request...
                URL url = new URL("http://" + SERVER_URL + //$NON-NLS-1$
                                  ":" + SERVER_PORT + //$NON-NLS-1$
                                  "/" + SERVER_CONTEXT); //$NON-NLS-1$
                HttpURLConnection connection = (HttpURLConnection)url.openConnection();
                connection.setRequestMethod("GET"); //$NON-NLS-1$
                connection.addRequestProperty("CustomerRef", customerRef); //$NON-NLS-1$
                int responseCode = connection.getResponseCode();
                if (responseCode != HttpURLConnection.HTTP_OK)
                {   //  OOPS! Error - JSON not GETted, so no
                    System.out.println("GET request did not work: " + responseCode); //$NON-NLS-1$
                }
                //  ...and make sure we've got back the same JSON
                StringBuilder sb = new StringBuilder();
                try (InputStream inputStream = connection.getInputStream();
                     InputStreamReader isr = new InputStreamReader(inputStream);
                     BufferedReader br = new BufferedReader(isr))
                {
                    String line;
                    while ((line = br.readLine()) != null)
                    {
                        if (sb.length() != 0)
                        {
                            sb.append('\n');
                        }
                        sb.append(line);
                    }
                }
                assert sb.toString().equals(_jsons.get(customerRef));
            }
            catch (IOException ex)
            {
                ex.printStackTrace();
            }
        }
    }
}
