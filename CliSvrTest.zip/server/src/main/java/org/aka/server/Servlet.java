package org.aka.server;

import java.io.*;
import java.sql.*;
import java.util.regex.*;
import javax.servlet.*;
import javax.servlet.annotation.*;
import javax.servlet.http.*;

/**
 *  The handler for HTTP requests.
 */
@SuppressWarnings("serial")
@WebServlet(name = "Servlet", urlPatterns = {"/server"})
public class Servlet extends HttpServlet
{
    //////////
    //  HttpServlet
    @Override
    public void init() throws ServletException
    {
        super.init();
        try
        {
            _dbConnection = _openDatabaseConnection();
        }
        catch (SQLException | ReflectiveOperationException ex)
        {
            ex.printStackTrace();
            throw new UnavailableException("Stopping Context due to database connection error"); //$NON-NLS-1$
        }
    }


    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        //  Fetch the customer ref parameter
        String customerRef = request.getHeader("CustomerRef"); //$NON-NLS-1$
        //  Find the database record
        try (PreparedStatement selectStatement =
                _dbConnection.prepareStatement(
                    "SELECT customerData" + //$NON-NLS-1$
                        "  FROM clientinfo" + //$NON-NLS-1$
                    " WHERE customerRef = ?")) //$NON-NLS-1$
        {
            selectStatement.setString(1, customerRef);
            try (ResultSet resultSet = selectStatement.executeQuery())
            {
                if (resultSet.next())
                {   //  There IS a result!
                    try (PrintWriter writer = response.getWriter())
                    {
                        writer.write(resultSet.getString(1));
                        writer.flush();
                    }
                    response.setStatus(HttpServletResponse.SC_OK);
                }
                else
                {   //  OOPS! No such customer!
                    response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
                }
            }
        }
        catch (SQLException ex)
        {
            ex.printStackTrace();
            response.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            throw new ServletException(ex);
        }
    }

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException
    {
        //  Assemble the entire POST request body
        StringBuilder sb = new StringBuilder();
        try (BufferedReader bodyReader = request.getReader())
        {
            String line;
            while ((line = bodyReader.readLine()) != null)
            {
                if (sb.length() != 0)
                {
                    sb.append('\n');
                }
                sb.append(line);
            }
        }
        //  We need to extract CustomerRef from a JSON string
        Matcher m = _customerRefPattern.matcher(sb.toString());
        if (m.find())
        {   //  Found it!
            String customerRef = m.group(1);
            try
            {
                _recordCustomerInfo(customerRef, sb.toString());
            }
            catch (SQLException ex)
            {   //  OOPS! Something is wrong on the database level
                response.setStatus(HttpServletResponse.SC_FORBIDDEN);
                ex.printStackTrace();
                return;
            }
            response.setStatus(HttpServletResponse.SC_OK);
        }
        else
        {   //  OOPS! No CustomerRef!
            response.setStatus(HttpServletResponse.SC_BAD_REQUEST);
        }
    }

    //////////
    //  Implementation
    private static final Pattern _customerRefPattern = Pattern.compile("\"CustomerRef\":\"([^\"]+)\""); //$NON-NLS-1$
    private Connection _dbConnection;

    //  Helpers
    @SuppressWarnings("static-method")
    private Connection _openDatabaseConnection() throws SQLException, ReflectiveOperationException
    {
        //  Load the driver...
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver").newInstance(); //$NON-NLS-1$
        }
        catch (InstantiationException | IllegalAccessException |
               ClassNotFoundException ex)
        {
            ex.printStackTrace();
            throw ex;
        }
        //  ...open the connection...
        return DriverManager.getConnection("jdbc:mysql://localhost/clisvrtest?" + //$NON-NLS-1$
                                           "user=akapusti&password=KaBoom512"); //$NON-NLS-1$
    }

    private void _recordCustomerInfo(String customerRef, String customerData) throws SQLException
    {
        //  Try to insert a new row first
        try (PreparedStatement insertStatement =
                _dbConnection.prepareStatement(
                    "INSERT INTO clientinfo" + //$NON-NLS-1$
                    "            (customerRef, customerData)" + //$NON-NLS-1$
                    "     VALUES (?,?)")) //$NON-NLS-1$
        {
            insertStatement.setString(1, customerRef);
            insertStatement.setString(2, customerData);
            insertStatement.execute();
        }
        catch (SQLException ex)
        {   //  Maybe customerRef is already in the database. Try UPDATE
            try (PreparedStatement updateStatement =
                    _dbConnection.prepareStatement(
                        "UPDATE clientinfo" + //$NON-NLS-1$
                        "   SET customerData = ?" + //$NON-NLS-1$
                        " WHERE customerRef = ?")) //$NON-NLS-1$
            {
                updateStatement.setString(1, customerData);
                updateStatement.setString(2, customerRef);
                if (updateStatement.executeUpdate() != 1)
                {   //  OOPS! Update failed too!
                    throw ex;
                }
            }
        }
    }
}
