Please, find attached my answer to the other (client/server + JSON) task. This is a ZIP containing:

* The Eclipse project for the client (that reads the CSV and makes JSON requests to the server).
* The Eclipse project for the server (which responds to the GET and POST requests).
* The Tomcat server configuration I have used for development.

The technologies involved are Windows 11, Java 8 and Tomcat 9. The database used by the server is MySQL, latest edition (8.2.0 at the time of writing this).

SOME NOTES:

* The task descriptgion suggested that I may want to save customer details in the database in the CSV-like form. I decided against that - if the client sends JSON to the server and expects to receive JSON back, we may as well save JSON into the database and avoid two data conversions there. Servers are usually busy enough as it is.
* I know MySQL is a relational database, but during my time at Enactor I have seen with some admiration how they used it as a document database for their entire code base. Normally the choice would have been something like MongoDB, but I'm just learning it, whilst MySQL I know inside and out.
* Like in the first assignment, there are built-in tests to make sure that the client GETs back exactly what it POSTed.
* The third-party libraries required by the code (JSON handler for the client and MySQL Connector/J for the server) are included in the corresponding projects.
* The test CSV file is included with the client.
* The MySQL database schema is included with the server.
* The database connection details may be different from my dev environment - they are specified in the MySQL connection string in the "implementation helpers" section of the server Servlett.
* I ran both client and server from Eclipse, with "-ea" flag on java.exe. Any assertion would have fired an exception.
* The decision for the server to "UPDATE or INSERT" customer info was deliberate. If someone gives the client a slightly updated CSV file with customers (one of them may have changed their address, for heaven's sake) I want the server operating as smoothly as possible.

SOME MORE NOTES:

* The code has a few "Exception.printStackTrace()" calls; in the production code they will be replaced by proper logging (Java's own, or log4j). I decided not to bother there, as, in my understanding, the purpose of this exercise was not to see how well I can write logs, but how well I understand REST microservices. Just as the "string calculator" test was to see how well I can come up with robust and correct algorithms.
* Total time taken to complete the test = 7 hours, of which almost 5 I've spend fighting with the Tomcat installation and making sure it works. What can I say? I'm not a sysadmin, or Tomcat admin for that matter - that's very visible in my CV. Over 30 years ago, the unwritten motto of our company was "needs must". So now I know a bit about how to configure Tomcat instead of just deploying webapps to an already configured instance. For that I must say special thanks - I always love to learn.
* Sorry I didn't use Java 8 Streams - they just didn't appear to be suitable for any of the tasks at hand. Regexes served far better, just like in the first exercise.

Very much hoping that results will meet with the client's approval,
    Andrey Kapustin
