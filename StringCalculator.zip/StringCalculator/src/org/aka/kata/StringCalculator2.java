package org.aka.kata;

import java.text.ParseException;

/**
 *  String Calculator Kata - version 2.
 */
public final class StringCalculator2
{
    //////////
    //  Operations
    /**
     *  Adds numbers represented by the string and returns the result.
     *  
     *  @param numbers
     *      The string containing 0, 1 or more ',' - separated numbers.
     *  @return
     *      The sum of all numbers in the string
     *  @throws ParseException
     *      If an error occurs. 
     */
    public static int Add(String numbers) throws ParseException
    {
        if (numbers == null || numbers.length() == 0)
        {   //  1.iii. An empty string should return a sum of 0.
            return 0;
        }
        //  1.iv. numbers can include 0, 1, or more integers (e.g. "", "1", "1,2", "1,2,3", etc.)
        String[] chunks = numbers.split(","); //$NON-NLS-1$
        //  1. v. Add returns the sum of the integers provided in the string numbers.
        int result = 0;
        try
        {
            for (var chunk : chunks)
            {
                int n = Integer.parseInt(chunk);
                int newResult = result + n;
                if (isNegative(result) == isNegative(n) && isNegative(newResult) != isNegative(result))
                {
                    throw new ParseException("Overflow processing '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
                }
                result = newResult;
            }
        }
        catch (@SuppressWarnings("unused") NumberFormatException ex)
        {   //  OOPS! Integer.parse() error!
            throw new ParseException("Invalid input '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
        }
        return result;
    }
    
    //////////
    //  Implementation helpers
    private static boolean isNegative(int n)
    {
        return n < 0;
    }
}
