package org.aka.kata;

import java.text.ParseException;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * String Calculator Kata - version 5.
 */
public final class StringCalculator5
{
    //////////
    // Operations
    /**
     *  Adds numbers represented by the string and returns the result.
     * 
     *  @param numbers 
     *      The string containing 0, 1 or more ',' or '\n' - separated
     *      numbers. Can start with "//delimiter\n" sequence, which
     *      treats delimiter as "numbers delimiter" IN ADDITION TO ','
     *      and '\n'. Calling Add with a negative number will throw 
     *      an exception.
     *  @return 
     *      The sum of all numbers in the string
     *  @throws 
     *      ParseException If an error occurs.
     */
    public static int Add(String numbers) throws ParseException
    {
        String numbersOnly = numbers;
        Character customDelimiter = null;
        if (numbersOnly != null && numbersOnly.startsWith("//") && //$NON-NLS-1$
            numbers.indexOf('\n') == 3)
        {
            customDelimiter = Character.valueOf(numbers.charAt(2));
            numbersOnly = numbers.substring(4);
        }

        // 1.iii. An empty string should return a sum of 0.
        if (numbersOnly == null || numbersOnly.length() == 0)
        {
            return 0;
        }
        // 1.iv.    numbers can include 0, 1, or 2 integers (e.g. "", "1", "1,2, "1,2\n3").
        // 3.       Allow the Add method to handle new lines between numbers (as well as commas):
        // 4.       Allow the Add method to handle a different delimiter:
        // 4.i.     To change the delimiter, the beginning of the string should be a
        //          separate line formatted like this: "//[delimiter]\n[numbers]"
        // 4.iii.   This first line is optional; all existing scenarios (using "," or
        //          "\n") should work as before.
        //  5.      Calling Add with a negative number will throw an exception 
        //          "Negatives not allowed: " and then listing all negative numbers 
        //          that were in the list of numbers.
        String[] chunks = Stream.of(numbersOnly.split(",")) //$NON-NLS-1$
                                .flatMap(c -> Stream.of(c.split("\n"))) //$NON-NLS-1$
                                .toArray(String[]::new);
        if (customDelimiter != null)
        {
            StringBuilder cdPatternBuilder = new StringBuilder();
            if (regexSpecialCharacters.contains(customDelimiter))
            {
                cdPatternBuilder.append('\\');
            }
            cdPatternBuilder.append(customDelimiter.charValue());
            final String cd = cdPatternBuilder.toString();  //  needed for use in a lambda
            chunks = Stream.of(chunks)
                           .flatMap(c -> Stream.of(c.split(cd)))
                           .toArray(String[]::new);
        }
        // 1. v. Add returns the sum of the integers provided in the string numbers.
        int result = 0;
        Set<Integer> negatives = new HashSet<>();
        try
        {
            for (var chunk : chunks)
            {
                int n = Integer.parseInt(chunk);
                if (n >= 0)
                {
                    int newResult = result + n;
                    if (isNegative(result) == isNegative(n) && isNegative(newResult) != isNegative(result))
                    {
                        throw new ParseException("Overflow processing '" + numbers + "'", 0); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    result = newResult;
                }
                else
                {
                    negatives.add(Integer.valueOf(n));
                }
            }
        } 
        catch (@SuppressWarnings("unused") NumberFormatException ex)
        { // OOPS! Integer.parse() error!
            throw new ParseException("Invalid input '" + numbers + "'", 0); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if (!negatives.isEmpty())
        {
            throw new ParseException("Negatives not allowed: " + negatives.toString(), 0); //$NON-NLS-1$
        }
        return result;
    }

    //////////
    // Implementation helpers
    private static final Set<Character> regexSpecialCharacters =
        "<([{\\^-=$!|]})?*+.>".chars() //$NON-NLS-1$
                              .mapToObj(c -> Character.valueOf((char)c))
                              .collect(Collectors.toSet());

    private static boolean isNegative(int n)
    {
        return n < 0;
    }
}
