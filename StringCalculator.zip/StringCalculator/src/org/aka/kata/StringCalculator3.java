package org.aka.kata;

import java.text.ParseException;
import java.util.stream.Stream;

/**
 *  String Calculator Kata - version 3.
 */
public final class StringCalculator3
{
    //////////
    //  Operations
    /**
     *  Adds numbers represented by the string and returns the result.
     *  
     *  @param numbers
     *      The string containing 0, 1 or more ',' or '\n' - separated numbers.
     *  @return
     *      The sum of all numbers in the string
     *  @throws ParseException
     *      If an error occurs. 
     */
    public static int Add(String numbers) throws ParseException
    {
        if (numbers == null || numbers.length() == 0)
        {   //  1.iii. An empty string should return a sum of 0.
            return 0;
        }
        //  1.iv.   numbers can include 0, 1, or 2 integers (e.g. "", "1", "1,2, "1,2\n3").
        //  3.      Allow the Add method to handle new lines between numbers (as well as commas):
        String[] chunks = Stream.of(numbers.split(",")) //$NON-NLS-1$
                                .flatMap(c -> Stream.of(c.split("\n"))) //$NON-NLS-1$
                                .toArray(String[]::new);
        //  1. v. Add returns the sum of the integers provided in the string numbers.
        int result = 0;
        try
        {
            for (var chunk : chunks)
            {
                int n = Integer.parseInt(chunk);
                int newResult = result + n;
                if (isNegative(result) == isNegative(n) && isNegative(newResult) != isNegative(result))
                {
                    throw new ParseException("Overflow processing '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
                }
                result = newResult;
            }
        }
        catch (@SuppressWarnings("unused") NumberFormatException ex)
        {   //  OOPS! Integer.parse() error!
            throw new ParseException("Invalid input '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
        }
        return result;
    }
    
    //////////
    //  Implementation helpers
    private static boolean isNegative(int n)
    {
        return n < 0;
    }
}
