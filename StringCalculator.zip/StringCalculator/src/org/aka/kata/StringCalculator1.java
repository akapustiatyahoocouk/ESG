package org.aka.kata;

import java.text.ParseException;

/**
 *  String Calculator Kata - version 1.
 */
public final class StringCalculator1 
{
    //////////
    //  Operations
    /**
     *  Adds numbers represented by the string and returns the result.
     *  
     *  @param numbers
     *      The string containing 0, 1 or 2 ',' - separated numbers.
     *  @return
     *      The sum of all numbers in the string
     *  @throws ParseException
     *      If an error occurs. 
     */
    public static int Add(String numbers) throws ParseException
    {
        if (numbers == null || numbers.length() == 0)
        {   //  1.iii. An empty string should return a sum of 0.
            return 0;
        }
        //  1.iv. numbers can include 0, 1, or 2 integers (e.g. "", "1", "1,2").
        String[] chunks = numbers.split(","); //$NON-NLS-1$
        //  1. v. Add returns the sum of the integers provided in the string numbers.
        int result;
        try
        {
            if (chunks.length == 1)
            {
                result = Integer.parseInt(chunks[0]);
            }
            else if (chunks.length == 2)
            {
                int n1 = Integer.parseInt(chunks[0]);
                int n2 = Integer.parseInt(chunks[1]);
                result = n1 + n2;
                if (isNegative(n1) == isNegative(n2) && isNegative(result) != isNegative(n1))
                {
                    throw new ParseException("Overflow processing '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
                }
            }
            else
            {
                throw new ParseException("Invalid input '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
            }
        }
        catch (@SuppressWarnings("unused") NumberFormatException ex)
        {   //  OOPS! Integer.parse() error!
            throw new ParseException("Invalid input '" + numbers + "'", 0);  //$NON-NLS-1$ //$NON-NLS-2$
        }
        return result;
    }
    
    //////////
    //  Implementation helpers
    private static boolean isNegative(int n)
    {
        return n < 0;
    }
}
