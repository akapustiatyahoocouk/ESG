package org.aka.kata.tests;

import java.text.ParseException;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.aka.kata.StringCalculator3;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *  String Calculator Kata - version 3 (test).
 */
public final class StringCalculator3Test
{
    //////////
    //  Tests
    @SuppressWarnings("static-method")
    @Test
    void testNull() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testEmpty() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testOneNumber() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add("1") == 1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testTwoNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add("1,2") == 3)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testManyNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add("1,2,-4") == -1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testEolnSeparators() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add("1\n2\n-4") == -1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testMixedSeparators() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator3.Add("1,2\n-4") == -1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testNonNumeric() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator3.Add("x")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testOverflow() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator3.Add("1500000000\n2000000000,500000000")); //$NON-NLS-1$
    }
}
