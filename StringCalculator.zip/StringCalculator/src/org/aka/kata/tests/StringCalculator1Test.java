package org.aka.kata.tests;

import java.text.ParseException;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.aka.kata.StringCalculator1;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *  String Calculator Kata - version 1 (test).
 */
public final class StringCalculator1Test
{
    //////////
    //  Tests
    @SuppressWarnings("static-method")
    @Test
    void testNull() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator1.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testEmpty() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator1.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testOneNumber() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator1.Add("1") == 1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testTwoNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator1.Add("1,2") == 3)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testNonNumeric() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator1.Add("x")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testTooManyFragments() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator1.Add("1,2,3")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testOverflow() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator1.Add("2000000000,2000000000")); //$NON-NLS-1$
    }
}
