package org.aka.kata.tests;

import java.text.ParseException;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.aka.kata.StringCalculator2;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *  String Calculator Kata - version 2 (test).
 */
public final class StringCalculator2Test
{
    //////////
    //  Tests
    @SuppressWarnings("static-method")
    @Test
    void testNull() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator2.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testEmpty() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator2.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testOneNumber() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator2.Add("1") == 1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testTwoNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator2.Add("1,2") == 3)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testManyNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator2.Add("1,2,-4") == -1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testNonNumeric() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator2.Add("x")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testOverflow() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator2.Add("1500000000,2000000000,500000000")); //$NON-NLS-1$
    }
}
