package org.aka.kata.tests;

import static org.junit.jupiter.api.Assertions.assertTrue;

import java.text.ParseException;

import org.aka.kata.StringCalculator8;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;

/**
 *  String Calculator Kata - version 7 (test).
 */
public final class StringCalculator8Test
{
    //////////
    //  Tests
    @SuppressWarnings("static-method")
    @Test
    void testNull() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testEmpty() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add(null) == 0));
    }

    @SuppressWarnings("static-method")
    @Test
    void testOneNumber() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1") == 1)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testTwoNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1,2") == 3)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testManyNumbers() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1,2,3") == 6)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testEolnSeparators() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1\n2\n4") == 7)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testMixedSeparators() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1,2\n4") == 7)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testNonNumeric() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator8.Add("x")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testOverflow() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1500000000\n2000000000,500000000") == 0)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testCustomDelimiter() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("//;\n1;2,4") == 7)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testMixedDelimiters() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("//;\n1;2,4\n5") == 12)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testStrangeDelimiters() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("//\\\n1\\2,4\n5") == 12)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testNegatives() 
    {
        Assertions.assertTrue(
            Assertions.assertThrowsExactly(ParseException.class, () -> StringCalculator8.Add("-1,2\n-4")) //$NON-NLS-1$
            .getMessage().startsWith("Negatives not allowed: ")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testVeryLarge() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1000,2") == 1002)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testTooLarge() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("1001,2") == 2)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testLongDelimiter() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator8.Add("//[|||]\n1|||2|||3")); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testAlternateDelimiter() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("//[|]\n1|2|3") == 6)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testAlternateDelimiters() 
    {
        Assertions.assertDoesNotThrow(() -> assertTrue(StringCalculator8.Add("//[|][%]\n1|2%3") == 6)); //$NON-NLS-1$
    }

    @SuppressWarnings("static-method")
    @Test
    void testEmptyDelimiter() 
    {
        Assertions.assertThrows(ParseException.class, () -> StringCalculator8.Add("//[|][][%]\n1|2%3")); //$NON-NLS-1$
    }
}
