package org.aka.kata;

import java.text.ParseException;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * String Calculator Kata - version 8.
 */
public final class StringCalculator8
{
    //////////
    // Operations
    /**
     *  Adds numbers represented by the string and returns the result.
     * 
     *  @param numbers 
     *      The string containing 0, 1 or more ',' or '\n' - separated
     *      numbers. Can start with "//delimiter\n" sequence, which
     *      treats delimiter as "numbers delimiter" IN ADDITION TO ','
     *      and '\n'. Calling Add with a negative number will throw 
     *      an exception, all numbers larger than 1000 will be ignored.
     *      The delimiter can be either a single character, a 
     *      non-empty "[sequence of characters]" or a choice of 1-character 
     *      delimiters "[d1][d2]...[dN]".
     *  @return 
     *      The sum of all numbers in the string
     *  @throws 
     *      ParseException If an error occurs.
     */
    public static int Add(String numbers) throws ParseException
    {
        String numbersOnly = numbers;
        //  Start with "standard" delimiters...
        Set<String> delimiters = Stream.of(",", "\n").collect(Collectors.toSet()); //$NON-NLS-1$ //$NON-NLS-2$
        if (numbersOnly != null && numbersOnly.startsWith("//")) //$NON-NLS-1$
        {   //  ...and add custom delimiters if any are specified
            int eolnIndex = numbers.indexOf('\n');
            if (eolnIndex == 3)
            {   //  A "single-character" delimiter
                delimiters.add(numbers.substring(2, 3));
                numbersOnly = numbers.substring(4);
            }
            else if (eolnIndex >= 5)
            {   //  A "[multi-character]" delimiter of "[d1][d2]...[dN]" delimiter sequence?
                String delimiterSpecification = numbers.substring(2, eolnIndex);
                if (delimiterSpecification.startsWith("[") && //$NON-NLS-1$
                    delimiterSpecification.endsWith("]")) //$NON-NLS-1$
                {
                    String delimiterOrSequence = delimiterSpecification.substring(1, delimiterSpecification.length() - 1);
                    if (delimiterOrSequence.indexOf("][") == -1) //$NON-NLS-1$
                    {   //  A "[multi-character]" delimiter
                        delimiters.add(delimiterOrSequence);
                    }
                    else
                    {   //  A "[d1][d2]...[dN]" delimiter sequence
                        delimiters.addAll(Arrays.asList(delimiterOrSequence.split("\\]\\["))); //$NON-NLS-1$
                    }
                    numbersOnly = numbers.substring(eolnIndex + 1);
                }
            }
            if (!delimiters.stream().allMatch(d -> d.length() == 1))
            {   //  OOPS! Not allowed for THIS exercise (8.)
                throw new ParseException("Invalid input '" + numbers + "'", 0); //$NON-NLS-1$ //$NON-NLS-2$
            }
        }
        
        // 1.iii. An empty string should return a sum of 0.
        if (numbersOnly == null || numbersOnly.length() == 0)
        {
            return 0;
        }
        //  1.iv.   numbers can include 0, 1, or 2 integers (e.g. "", "1", "1,2, "1,2\n3").
        //  3.      Allow the Add method to handle new lines between numbers (as well as commas):
        //  4.      Allow the Add method to handle a different delimiter:
        //  4.i.    To change the delimiter, the beginning of the string should be a
        //          separate line formatted like this: "//[delimiter]\n[numbers]"
        //  4.iii.  This first line is optional; all existing scenarios (using "," or
        //          "\n") should work as before.
        //  5.      Calling Add with a negative number will throw an exception 
        //          "Negatives not allowed: " and then listing all negative numbers 
        //          that were in the list of numbers.
        //  6.      Numbers greater than 1000 should be ignored.
        //  7.      Delimiters can be any length, using this syntax: "//[|||]\n1|||2|||3" returns 6.
        //  8.      Allow multiple delimiters, using this syntax: "//[|][%]\n1|2%3" returns 6.
        String regex =
            String.join(
                "|",  //$NON-NLS-1$
                Stream.of(delimiters.toArray(String[]::new))
                      .map(d -> escapeStringForRegex(d))
                      .toArray(String[]::new));
        String[] chunks = numbersOnly.split(regex);
        // 1. v. Add returns the sum of the integers provided in the string numbers.
        int result = 0;
        Set<Integer> negatives = new HashSet<>();
        try
        {
            for (var chunk : chunks)
            {
                int n = Integer.parseInt(chunk);
                if (n > 1000)
                {   //  6.  Numbers greater than 1000 should be ignored.
                }
                else if (n >= 0)
                {
                    int newResult = result + n;
                    if (isNegative(result) == isNegative(n) && isNegative(newResult) != isNegative(result))
                    {
                        throw new ParseException("Overflow processing '" + numbers + "'", 0); //$NON-NLS-1$ //$NON-NLS-2$
                    }
                    result = newResult;
                }
                else
                {
                    negatives.add(Integer.valueOf(n));
                }
            }
        } 
        catch (@SuppressWarnings("unused") NumberFormatException ex)
        {   // OOPS! Integer.parse() error!
            throw new ParseException("Invalid input '" + numbers + "'", 0); //$NON-NLS-1$ //$NON-NLS-2$
        }
        if (!negatives.isEmpty())
        {
            throw new ParseException("Negatives not allowed: " + negatives.toString(), 0); //$NON-NLS-1$
        }
        return result;
    }

    //////////
    // Implementation helpers
    private static final Set<Character> regexSpecialCharacters =
            "<([{\\^-=$!|]})?*+.>".chars() //$NON-NLS-1$
                                  .mapToObj(c -> Character.valueOf((char)c))
                                  .collect(Collectors.toSet());
    
    private static boolean isNegative(int n)
    {
        return n < 0;
    }
    
    private static String escapeStringForRegex(String s)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < s.length(); i++)
        {
            char c = s.charAt(i);
            if (regexSpecialCharacters.contains(Character.valueOf(c)))
            {
                sb.append('\\');
            }
            sb.append(c);
        }
        return sb.toString();
    }
}
